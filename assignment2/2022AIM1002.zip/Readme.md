# How to run the code?

1. Run ExtendibleHash.java file. It asks for Bucket_Size.
2. Put data in dataset.txt file in csv format.

# Files information

1. Utility.java file contains Utility class which contains functions which are being used oftenly.
2. SimulatedSecondaryMemory.java file contains SimulatedSecondaryMemory class which represents the SimulatedSecondaryMemory containing list of empty buckets initially.
3. Bucket.java file contains Bucket class which represents a Bucket.

